<?php 
   include("adminheading.php"); 
?>


        <div class="row">
            <div class="col-lg-3 md-12">
               <ul>
               <a class="module btn btn-primary" href="admin.php">Admin Portal</a>
                
               </ul>
               
                
            </div>
            <div class="col-lg-3 md-12">
               <ul>
                <a href="bityear1.php"><div class="module btn btn-primary">My marks</div></a>
                
               </ul>
               
                
            </div>
            <div class="col-lg-3 md-12">
            <a class="module btn btn-primary printmarks" onclick="window.print()" href="">Print</a>
               
                
            </div>
            <div class="col-lg-3 md-12">
               
               
                
            </div>
        </div>
        <div class="row body">
            <div class="col-lg-12 md-12">
                <h1 class="bg-primary heading1">ALL STUDENTS MARKS</h1>
                <div class="column">
                    <table class="allmarks table1 table table-striped table-hover">
                        <thead class=" text-light bg-primary">
                            <tr>
                                <th>REGNUMBER</th>
                                <th>FIRSTNAME</th>
                                <th>LASTNAME</th>
                                <th>QUIZ&ASSIGNMENT</th>
                                <th>CAT</th>
                                <th>TOTAL</th>
                                <th>FINALEXAM</th>
                                <th>TOTAL</th>
                                <th>MODULENAME</th>
                                <th>STATUS</th>
                                <th colspan="2">ACTION</th>
                            </tr>
                        </thead>
                        <?php 
                            $x=1;
                            $select = mysqli_query($conn,"SELECT marks.markId, student.regNumber, marks.quizAndAssignments, marks.cat, marks.totalCatAndAssignments, marks.finalExam, marks.totalPercent, module.name, year_of_study.yearOfStudy, student.firstName, student.lastName, marks.status FROM marks, module, student, year_of_study WHERE marks.moduleCode = module.moduleCode AND marks.regNumber = student.regNumber AND marks.yearId = year_of_study.yearId ");
                                while($rows = mysqli_fetch_array($select))
                                {

                        ?>
                        <tr>
                            <td><?php echo $rows['regNumber'];?></td>
                            <td><?php echo $rows['firstName'];?></td>
                            <td><?php echo $rows['lastName'];?></td>
                            <td><?php echo $rows['quizAndAssignments'];?></td>
                            <td><?php echo $rows['cat'];?></td>
                            <td><?php echo $rows['totalCatAndAssignments'];?></td>
                            <td><?php echo $rows['finalExam'];?></td>
                            <td><?php echo $rows['totalPercent'];?></td>
                            <td><?php echo $rows['name'];?></td>
                            <td><?php echo $rows['status'];?></td>
                            <td><a href="updatemarks.php?markId=<?=$rows['markId'];?>"><span class="btn btn-primary">Update</span></a></td>
                            <td><a href="deletemarks.php?markId=<?=$rows['markId'];?>"><span onclick="return confirmDelete();" class="btn btn-danger">Delete</span></a></td>
                            
                        </tr>
                        <?php $x++; } ?>
                    </table>
                </div>
                
            </div>

        </div>
   </div>
</body>
</html>