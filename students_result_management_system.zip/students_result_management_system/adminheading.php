<?php
session_start();
include("connection.php");
$admin_regnumber = $_SESSION['regnumber'];
$user_type = mysqli_query($conn, "SELECT userType FROM student WHERE regNumber = '$admin_regnumber'");
while($user_type_Row = mysqli_fetch_array($user_type))
{
    $admin_userType = $user_type_Row['userType'];
    if( $admin_userType != "Admin")
    {
        header("location:index.php");
    }
}
if($_SESSION['regnumber'] == "")
{
    header("location:index.php");
} 

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title class="title">STUDENT RESULTS MANAGEMENT SYSTEM</title>
    <link rel="stylesheet" href="./bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <script src="./javascript/myscript.js"></script>
</head>
<body>
   <div class="main container-fluid">
        <div class="row heading marks bg-primary">
            <div class="col-lg-3 col-md-12">
                <div class="profile">
                    <?php 
                            $profile_image =   $_SESSION['regnumber'];
                        
                    ?>
                        <img class="profile_icon" src="<?php echo "./images/" . $profile_image . ".jpg"?>" alt="icon">
                </div>
                <div class="profile_name">
                    <span>Admin:</span>
                    <?php echo $_SESSION['fname'];?>
                    <?php echo $_SESSION['lname'];?>
                </div>

            </div>
            <div class="col-lg-6 col-md-12">
                <div class="title">
                <h1 class="title1">STUDENT RESULTS MANAGEMENT SYSTEM</h1>  
                </div>
                
            </div>
            <div class="logout_div col-lg-3 col-md-12">
                <a href="logout.php"><div onclick="return confirmLogout();" class="logout">Logout</div></a>
            </div>
        </div>
        <hr>