<?php 
    include("connection.php");
    $moduleCode=$_GET['moduleCode'];
    
    $delete = mysqli_query($conn,"DELETE FROM module WHERE moduleCode=$moduleCode");
	if($delete){
		header("location:modulelist.php");
	}

?>