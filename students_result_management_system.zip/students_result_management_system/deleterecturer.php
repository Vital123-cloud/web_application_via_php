<?php 
    include("connection.php");
    $recturerId=$_GET['recturerId'];
    
    $delete = mysqli_query($conn,"DELETE FROM recturer WHERE recturerId=$recturerId");
	if($delete){
		header("location:recturerlist.php");
	}

?>