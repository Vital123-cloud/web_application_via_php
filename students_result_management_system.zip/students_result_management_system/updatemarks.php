        <?php
            include("adminheading.php");
            $markId = $_GET['markId'];
            $selectmarks = mysqli_query($conn,"SELECT * FROM marks WHERE markId = '$markId'");
            $marks_data=mysqli_fetch_assoc($selectmarks);
            if(isset($_POST['save'])){
                $markId = $_POST['markId'];
                $module = $_POST['module'];
                $regnumber = $_POST['regnumber'];
                $cat = $_POST['cat'];
                $quizandassignment = $_POST['quizandassignment'];
                $finalexam = $_POST['finalexam'];
                $yearofstudy = $_POST['yearofstudy'];
                $total_cat_assignment = $quizandassignment +  $cat;
                $totalmarks = $total_cat_assignment + $finalexam;
                if($totalmarks >= 50)
                {
                $status = "PASS";
                }
                else
                {
                $status = "FAIL";
                }
                

                $update=mysqli_query($conn,"UPDATE marks SET quizAndAssignments = '$quizandassignment', cat	= '$cat', totalCatAndAssignments = ' $total_cat_assignment', finalExam = '$finalexam', totalPercent = '$totalmarks', moduleCode = '$module', yearId = '$yearofstudy', regNumber = '$regnumber', status = '$status' WHERE markId  = '$markId'");
                if($update)
                {
                    header("location:studentmarks.php");
                }
                else{
                    header("location:admin.php");
                }

            }
            
        ?>


        <div class="row body">
            <div class="col-lg-3 md-12">
                  
            </div>
            <div class="col-lg-6 md-12">
               
                <div class="box">
                    <h1 class="form_head">UPDATE MARKS</h1>
                    <form class="mainform" action="updatemarks.php" method="POST">
                        <input class="input" type="hidden" name="markId" value="<?php echo $marks_data['markId'];?>">
                        <div class="row">
                            <div class="col-lg-6 col-md-12 col-sm-12">
                                <label class="label" for="module">Module:</label><br>
                                <select class="input" name="module" required>
                                    <?php
                                        $module = mysqli_query($conn, "SELECT * FROM module");
                                        while($module_data = mysqli_fetch_array($module))   
                                        {
                                            
                                    ?>
                                    <option value="<?php echo $module_data['moduleCode'];?>"><?php echo $module_data['name'];?></option>
                                    <?php }?> 
                                </select>
                                <?php

                                ?>
                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="year of study">Year Of Study:</label><br>
                                <select class="input" name="yearofstudy">
                                    <?php
                                        $year = mysqli_query($conn, "SELECT * FROM year_of_study");
                                        while($year_data = mysqli_fetch_array($year))
                                        {
                    
                                    ?>
                                    <option value="<?php echo $year_data['yearId'];?>"><?php echo $year_data['yearOfStudy'];?></option>
                                    <?php }?> 
                                </select>
                            </div>  
                            
                        </div>
                        
                        <div class="row">
                            
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="reg number">Reg Number:</label><br>
                                <input class="input" type="number" name="regnumber" value="<?php echo $marks_data['regNumber'];?>" required>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="cat">Cat/30:</label><br>
                                <input class="input" type="number" name="cat" value="<?php echo $marks_data['cat'];?>"><br>
                                
                                
                            </div>
                        </div>
                        <div class="row">
                            
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="quiz">Quiz + Assignment/20:</label><br>
                                <input class="input" type="number" name="quizandassignment" value="<?php echo $marks_data['quizAndAssignments'];?>"><br>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="final exam">Final EXam/50:</label><br>
                                <input class="input" type="number" name="finalexam" value="<?php echo $marks_data['finalExam'];?>">
                            </div>
                           
                            
                        </div>
                                            
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                

                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <input class="button button1 btn btn-primary" type="submit" name="save" value="Update">
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                
                                
                            </div>
                           
                            
                        </div>
                    </form>
                </div>
                <center><a href="studentmarks.php"><div class="btn btn-primary recturerback">Back</div></a></center>
            </div>
            <div class="col-lg-3 md-12">
                  
            </div>

        </div>





    </div>
</body>
</html>