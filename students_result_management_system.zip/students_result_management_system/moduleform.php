        <?php
        include("adminheading.php");
        $message ="";

        if(isset($_POST['save']))
        {
        $modulename = $_POST['modulename'];
        $numberofcredits = $_POST['numberofcredits'];
        $yearofstudy = $_POST['yearofstudy'];
        $recturer = $_POST['recturer'];
        $department = $_POST['department'];
        if(!empty($modulename))
        {
            if($insert = mysqli_query($conn, "INSERT INTO module VALUES('', '$modulename','$numberofcredits' ,'$yearofstudy' , '$recturer', '$department')"))
            {
                header("location:moduleform.php");
            }
        }
        else{
            $message = "All Fields Are Required";
        }
        }
        ?>
        <div class="row">
            <div class="col-lg-3 md-12">

            </div>
            <div class="col-lg-6 md-12">
                <div class="box recturerbox">
                    <h1 class="form_head">ADD MODULES</h1>
                    <center><span class="message"><?php echo $message;?></span></center>
                    <form class="mainform" action="moduleform.php" method="POST">
                        <div class="row">
                            <div class="col-lg-6 col-md-12 col-sm-12">
                                <label class="label" for="module">Module Name:</label><br>
                                <input class="input" type="text" name="modulename" placeholder="Enter Module Name Here">
                            </div>
                        </div>
                        
                        <div class="row">
                            
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="number of credits">Number Of Credits:</label><br>
                                <select class="input" name="numberofcredits">
                                    <option value="10">10</option>
                                    <option value="15">15</option>
                                    <option value="20">20</option>
                                </select>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="year of study">Year Of Study:</label><br>
                                <select class="input" name="yearofstudy">
                                    <?php
                                        $year = mysqli_query($conn, "SELECT * FROM year_of_study");
                                        while($year_data = mysqli_fetch_array($year))
                                        {
                    
                                    ?>
                                    <option value="<?php echo $year_data['yearId'];?>"><?php echo $year_data['yearOfStudy'];?></option>
                                    <?php }?> 
                                </select>
                                
                                
                            </div>
                        </div>
                        <div class="row">
                            
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="recturer">Recturer:</label><br>
                                <select class="input" name="recturer">
                                    <?php
                                        $recturer = mysqli_query($conn, "SELECT * FROM recturer");
                                        while($recturer_data = mysqli_fetch_array($recturer))
                                        {
                    
                                    ?>
                                    <option value="<?php echo $recturer_data['recturerId'];?>"><?php echo $recturer_data['firstName'] . " ". $recturer_data['lastName'];?></option>
                                    <?php }?> 
                                </select>
                                
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="department">Department:</label><br>
                                <select class="input" name="department">
                                    <?php
                                        $department = mysqli_query($conn, "SELECT * FROM department");
                                        while($department_data = mysqli_fetch_array($department))
                                        {
                    
                                    ?>
                                    <option value="<?php echo $department_data['departmentId'];?>"><?php echo $department_data['departmentName'];?></option>
                                    <?php }?> 
                                </select>
                               
                            </div>
                           
                            
                        </div>
                                            
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <input class="button button1 btn btn-primary" type="submit" name="save" value="Add">

                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <input class="button button2 btn btn-danger" type="reset" value="Cancel">
                                
                            </div>
                           
                            
                        </div>
                    </form>
                </div>
                <center><a href="admin.php"><div class="btn btn-primary recturerback">Back</div></a></center>
            </div>
            <div class="col-lg-3 md-12">

            </div>

        </div>









    </div>
</body>
</html>