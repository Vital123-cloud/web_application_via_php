<?php
include("adminheading.php");

?>

        <div class="row body">
            <div class="col-lg-3 md-12">
                
                <a href="admin.php"><div class="module btn btn-primary">Back</div></a>
                
                <a class="module btn btn-primary printmarks" onclick="window.print()" href="">Print</a>
            </div>
            <div class="col-lg-6 md-12">
                <div class="column">
                    <table class="allmarks table1 table table-striped table-hover">
                        <thead class=" text-light bg-primary">
                            <tr>
                                <th>NO</th>
                                <th>DEPARTMENT NAME</th>
                                <th>SCHOOL NAME</th>
                            </tr>
                        </thead>
                        <?php 
                            $x=1;
                            $select = mysqli_query($conn,"SELECT department.departmentName, school.schoolName FROM department, school WHERE department.schoolId = school.schoolId");
                                while($rows = mysqli_fetch_array($select))
                                {

                        ?>
                        <tr>
                            <td><?php echo $x;?></td>
                            <td><?php echo $rows['departmentName'];?></td>
                            <td><?php echo $rows['schoolName'];?></td>
                        </tr>
                        <?php $x++; } ?>
                    </table>
                </div>
                
            </div>
            <div class="col-lg-3 md-12">

            </div>

        </div>
   </div>
</body>
</html>