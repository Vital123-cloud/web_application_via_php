function confirmLogout() {
    return confirm("Are you Sure You Want to Log Out?");
}
function confirmDelete() {
    return confirm("Are you Sure You Want to Delete This Row?");
}