        <?php
            include("adminheading.php");
            $moduleCode = $_GET['moduleCode'];
            $select = mysqli_query($conn,"SELECT * FROM module WHERE moduleCode = '$moduleCode'");
            $data=mysqli_fetch_assoc($select);
            if(isset($_POST['save']))
            {
                $Code = $_POST['moduleCode'];
                $modulename = $_POST['modulename'];
                $numberofcredits = $_POST['numberofcredits'];
                $yearofstudy = $_POST['yearofstudy'];
                $recturer = $_POST['recturer'];
                $department = $_POST['department'];

                $update=mysqli_query($conn,"UPDATE module SET name ='$modulename', numberOfCredits='$numberofcredits', yearId='$yearofstudy', recturerId='$recturer', departmentId = '$department' WHERE moduleCode = '$Code'");
                if($update)
                {
                    header("location:modulelist.php");
                }
                else{
                    header("location:moduleform.php");
                }

            }

        ?>
        <div class="row">
            <div class="col-lg-3 md-3 sm-12">

            </div>
            <div class="col-lg-6 md-6 sm-12">
                <div class="box recturerbox">
                    <h1 class="form_head">UPDATE MODULE</h1>
                    <form class="mainform" action="updatemodule.php" method="POST">
                        <div class="row">
                            <div class="col-lg-6 col-md-12 col-sm-12">
                                <input class="input" type="hidden" name="moduleCode" value="<?php echo $data['moduleCode'];?>" required>
                                <label class="label" for="module">Module Name:</label><br>
                                <input class="input" type="text" name="modulename" value="<?php echo $data['name'];?>" placeholder="Enter Module Name Here" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="number of credits">Number Of Credits:</label><br>
                                <input class="input" type="text" name="numberofcredits" value="<?php echo $data['numberOfCredits'];?>" placeholder="Enter Module Name Here" required>
                                
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="year of study">Year Of Study:</label><br>
                                <select class="input" name="yearofstudy">
                                    <?php
                                        $year = mysqli_query($conn, "SELECT * FROM year_of_study");
                                        while($year_data = mysqli_fetch_array($year))
                                        {
                    
                                    ?>
                                    <option value="<?php echo $year_data['yearId'];?>"><?php echo $year_data['yearOfStudy'];?></option>
                                    <?php }?> 
                                </select>
                                
                                
                            </div>
                        </div>
                        <div class="row">
                            
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="recturer">Recturer:</label><br>
                                <select class="input" name="recturer">
                                    <?php
                                        $recturer = mysqli_query($conn, "SELECT * FROM recturer");
                                        while($recturer_data = mysqli_fetch_array($recturer))
                                        {
                    
                                    ?>
                                    <option value="<?php echo $recturer_data['recturerId'];?>"><?php echo $recturer_data['firstName'] . " ". $recturer_data['lastName'];?></option>
                                    <?php }?> 
                                </select>
                                
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="department">Department:</label><br>
                                <select class="input" name="department">
                                    <?php
                                        $department = mysqli_query($conn, "SELECT * FROM department");
                                        while($department_data = mysqli_fetch_array($department))
                                        {
                    
                                    ?>
                                    <option value="<?php echo $department_data['departmentId'];?>"><?php echo $department_data['departmentName'];?></option>
                                    <?php }?> 
                                </select>
                                
                            </div>
                            
                            
                        </div>
                                            
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12">
                            <input class="button button1 btn btn-primary" type="submit" name="save" value="Update">

                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                
                            </div>
                        </div>
                    </form>
                </div>
                <center><a href="modulelist.php"><div class="btn btn-primary recturerback">Back</div></a></center>
            </div>
            <div class="col-lg-3 md-3 sm-12">
                
            </div>
        </div>

        


    </div>
</body>
</html>