-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 19, 2024 at 02:34 PM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `university_of_rwanda_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `campus`
--

DROP TABLE IF EXISTS `campus`;
CREATE TABLE IF NOT EXISTS `campus` (
  `campusId` int NOT NULL AUTO_INCREMENT,
  `campusName` varchar(100) NOT NULL,
  PRIMARY KEY (`campusId`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `campus`
--

INSERT INTO `campus` (`campusId`, `campusName`) VALUES
(1, 'HUYE');

-- --------------------------------------------------------

--
-- Table structure for table `college`
--

DROP TABLE IF EXISTS `college`;
CREATE TABLE IF NOT EXISTS `college` (
  `collegeId` int NOT NULL AUTO_INCREMENT,
  `collegeName` varchar(100) NOT NULL,
  `campusId` int NOT NULL,
  PRIMARY KEY (`collegeId`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `college`
--

INSERT INTO `college` (`collegeId`, `collegeName`, `campusId`) VALUES
(1, 'CBE', 1);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `departmentId` int NOT NULL AUTO_INCREMENT,
  `departmentName` varchar(100) NOT NULL,
  `schoolId` int NOT NULL,
  PRIMARY KEY (`departmentId`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`departmentId`, `departmentName`, `schoolId`) VALUES
(1, 'Business Information Technology', 1),
(2, 'Logistic and Transport Management', 1),
(3, 'Accounting', 1),
(4, 'Ecomics', 2);

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

DROP TABLE IF EXISTS `marks`;
CREATE TABLE IF NOT EXISTS `marks` (
  `markId` int NOT NULL AUTO_INCREMENT,
  `quizAndAssignments` float NOT NULL,
  `cat` float NOT NULL,
  `totalCatAndAssignments` float NOT NULL,
  `finalExam` float NOT NULL,
  `totalPercent` float NOT NULL,
  `moduleCode` int NOT NULL,
  `yearId` int NOT NULL,
  `regNumber` int NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`markId`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

DROP TABLE IF EXISTS `module`;
CREATE TABLE IF NOT EXISTS `module` (
  `moduleCode` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `numberOfCredits` int NOT NULL,
  `yearId` int NOT NULL,
  `recturerId` int NOT NULL,
  `departmentId` int NOT NULL,
  PRIMARY KEY (`moduleCode`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`moduleCode`, `name`, `numberOfCredits`, `yearId`, `recturerId`, `departmentId`) VALUES
(1, 'Fundamental of Statistics', 15, 2, 1, 7),
(2, 'English for Specific Purposes', 10, 2, 2, 7),
(3, 'Database Management System', 15, 2, 3, 7),
(4, 'System Engineering', 15, 2, 4, 7),
(5, 'Data Structure and Algorithm', 15, 2, 5, 7),
(6, 'Business Function', 10, 2, 6, 7),
(11, 'English For Academic Purposes', 10, 1, 2, 7),
(12, 'Introduction to Financial Accounting', 10, 1, 9, 7),
(13, 'Business Management', 10, 1, 14, 7),
(14, 'Organization Theory and Behaviors', 10, 1, 11, 7),
(15, 'Information Technology', 10, 1, 10, 7),
(16, 'Citizenship and Transformative Education', 10, 1, 7, 7),
(17, 'Principles of Economics', 10, 1, 13, 7),
(18, 'Computer Architecture and Operating System', 10, 1, 10, 7),
(19, 'Fundamentals of Mathematics', 15, 1, 1, 7),
(20, 'Intermediate to Financial Accounting', 15, 1, 12, 7),
(21, 'Entrepreneurship and Innovation', 10, 1, 8, 7);

-- --------------------------------------------------------

--
-- Table structure for table `recturer`
--

DROP TABLE IF EXISTS `recturer`;
CREATE TABLE IF NOT EXISTS `recturer` (
  `recturerId` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`recturerId`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `recturer`
--

INSERT INTO `recturer` (`recturerId`, `firstName`, `lastName`, `gender`, `email`) VALUES
(1, 'Idrissa', 'KAYIJUka', 'Male', 'idrisakayijuka@gmail.com'),
(2, 'Aime', 'IRANKUNDA', 'Male', 'aimeirankunda@gmail.com'),
(3, 'Jeniffer', 'BATAMULIZA', 'Female', 'jeniffer@gmail.com'),
(4, 'Marc', 'SENTWALI', 'Male', 'msentwali@ur.ac.rw'),
(5, 'Prince ', 'RUKUNDO', 'Male', 'princerukundo@gmail.com'),
(6, 'Egidia', 'INGABIRE', 'Female', 'egidiaingabire@gmail.com'),
(7, 'Nathan', 'Karuhanga', 'Male', ''),
(8, 'Jean Claude', 'Bicakungeri', 'Male', ''),
(9, 'Jean Bosco', 'Shema', 'Male', ''),
(10, 'Christine', 'Ndikubwimana', 'Female', ''),
(11, 'Celestin', 'Musekura', 'Male', ''),
(12, 'Aline', 'Ingabire', 'Female', ''),
(13, 'Kizito', 'Nizeyimana', 'Male', ''),
(14, 'Jeannette', 'Muberarugo', 'Female', ''),
(15, 'Roger', 'MUREMYI', 'Male', 'evodemuyisingize@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `roleId` int NOT NULL AUTO_INCREMENT,
  `role` varchar(50) NOT NULL,
  PRIMARY KEY (`roleId`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`roleId`, `role`) VALUES
(1, 'Admin'),
(2, 'Student');

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

DROP TABLE IF EXISTS `school`;
CREATE TABLE IF NOT EXISTS `school` (
  `schoolId` int NOT NULL AUTO_INCREMENT,
  `schoolName` varchar(100) NOT NULL,
  `collegeId` int NOT NULL,
  PRIMARY KEY (`schoolId`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`schoolId`, `schoolName`, `collegeId`) VALUES
(1, 'School of Business', 1),
(2, 'School of Economics', 1);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `regNumber` int NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `phoneNumber` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `yearOfStudy` varchar(50) NOT NULL,
  `departmentId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `userType` varchar(50) NOT NULL,
  PRIMARY KEY (`regNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`regNumber`, `password`, `firstName`, `lastName`, `gender`, `phoneNumber`, `email`, `yearOfStudy`, `departmentId`, `userType`) VALUES
(223002996, '123', 'Vital', 'NKUNDIMANA', 'Male', '0787433196', 'nkunda.vital@gmail.com', 'Year 2', '1', 'Admin'),
(223002886, '123', 'Evode', 'MUYISINGIZEMWESE', 'Male', '0787433196', 'evodemuyisingize@gmail.com', 'Year 1', '1', 'Student'),
(222, '333', 'Emmy', 'niyikiza', 'Male', '55643', 'evodemuyisingize@gmail.com', 'Year 1', '1', 'Student');

-- --------------------------------------------------------

--
-- Table structure for table `year_of_study`
--

DROP TABLE IF EXISTS `year_of_study`;
CREATE TABLE IF NOT EXISTS `year_of_study` (
  `yearId` int NOT NULL AUTO_INCREMENT,
  `yearOfStudy` varchar(50) NOT NULL,
  PRIMARY KEY (`yearId`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `year_of_study`
--

INSERT INTO `year_of_study` (`yearId`, `yearOfStudy`) VALUES
(1, 'Year 1'),
(2, 'Year 2'),
(3, 'Year 3'),
(4, 'Year 4');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
