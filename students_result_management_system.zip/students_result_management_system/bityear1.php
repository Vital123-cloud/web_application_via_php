<?php
    include("heading.php");
?>

        <div class="row bo body">
            <a href="dashboard.php"><div class="btn btn-primary yearback">Back</div></a>
               
            <div class="boxyear modules col-lg-4 md-12">
                <h2 class="selectyear header2 bg-primary text-light">SELECT YEAR OF STUDY</h2>
                <a class="year_active module btn btn-primary" href="bityear1.php">Year One</a> <br>
                <a class="module btn btn-primary" href="bityear2.php">Year Two</a> <br>
                <a class="module btn btn-primary" href="bityear3.php">Year Three</a> <br>
                <a class="module btn btn-primary" href="bityear4.php">Year Four</a> <br>
            </div>
            <div class="col-lg-1 md-12">
               
                
            </div>
            
                
            
            <div class="box boxmodule col-lg-6 md-12">
                <h2 class="header2 bg-primary text-light">AVAILABLE MODULES</h2>
                <a class=" module btn btn-primary" href="english1.php">English For Academic Purposes</a> <br>
                <a class=" module btn btn-primary" href="financial.php">Introduction to Financial Accounting</a> <br>
                <a class=" module btn btn-primary" href="management.php">Business Management</a> <br>
                <a class=" module btn btn-primary" href="organization.php">Organization Theory and Behaviors</a> <br>
                <a class=" module btn btn-primary" href="it.php">Information Technology</a> <br>
                <a class=" module btn btn-primary" href="citizenship.php">Citizenship and Transformative Education</a> <br>
                <a class=" module btn btn-primary" href="economicsmodule.php">Principles of Economics</a> <br>
                <a class=" module btn btn-primary" href="architecture.php">Computer Architecture and Operating System</a> <br>
                <a class=" module btn btn-primary" href="fundamentalmathematics.php">Fundamentals of Mathematics</a> <br>
                <a class=" module btn btn-primary" href="intermediate.php">Intermediate to Financial Accounting</a> <br>
                <a class=" module btn btn-primary" href="entrepreneurship.php">Entrepreneurship and Innovation</a> <br>
                <a href="year1final.php"><div class="btn btn-primary back2 back2annual">Annual Year One Marks</div></a>
            </div>
            <div class="col-lg-1 md-12">
               
                
            </div>
            
            

        </div>
   </div>
</body>
</html>