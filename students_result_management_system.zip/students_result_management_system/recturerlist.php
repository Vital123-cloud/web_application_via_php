<?php
include("adminheading.php");
?>
        <div class="row body">
            <div class="col-lg-2 md-12">
                
                <a href="admin.php"><div class="module btn btn-primary">Back</div></a>
                
                <a class="module btn btn-primary printmarks" onclick="window.print()" href="">Print</a>
            </div>
            <div class="col-lg-10 md-12">
                <h1 class="bg-primary heading1">ALL RECTURERS LISTE</h1>
                <div class="column">
                    <table class="allmarks table1 table table-striped table-hover">
                        <thead class=" text-light bg-primary">
                            <tr>
                                <th>NO</th>
                                <th>FIRST NAME</th>
                                <th>LAST NAME</th>
                                <th>GENDER</th>
                                <th colspan="2">ACTION</th>
                               
                            </tr>
                        </thead>
                        <?php 
                            $x=1;
                            $select = mysqli_query($conn,"SELECT * FROM recturer");
                                while($rows = mysqli_fetch_array($select))
                                {

                        ?>
                        <tr>
                            <td><?php echo $x;?></td>
                            <td><?php echo $rows['firstName'];?></td>
                            <td><?php echo $rows['lastName'];?></td>
                            <td><?php echo $rows['gender'];?></td>
                            <td><a href="updaterecturer.php?recturerId=<?=$rows['recturerId'];?>"><span class="btn btn-primary">Update</span></a></td>
                            <td><a href="deleterecturer.php?recturerId=<?=$rows['recturerId'];?>"><span onclick="return confirmDelete();" class="btn btn-danger">Delete</span></a></td>
                            
                        </tr>
                        <?php $x++; } ?>
                    </table>
                </div>
                
            </div>
            
            

        </div>
   </div>
</body>
</html>