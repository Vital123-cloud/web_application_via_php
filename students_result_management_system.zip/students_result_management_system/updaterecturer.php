        <?php
        include("adminheading.php");
            $recturerId=$_GET['recturerId'];
            $select = mysqli_query($conn,"SELECT * FROM recturer WHERE recturerId = '$recturerId'");
            $data=mysqli_fetch_assoc($select);
            if(isset($_POST['save']))
            {
                $id = $_POST['recturerId'];
                $fname = $_POST['fname'];
                $lname = $_POST['lname'];
                $gender = $_POST['gender'];
                $email = $_POST['email'];
                $update=mysqli_query($conn,"UPDATE recturer SET firstName='$fname', lastName='$lname', gender='$gender', email='$email' WHERE recturerId = '$id'");
                if($update)
                {
                    header("location:recturerlist.php");
                }
                else{
                    header("location:recturerform.php");
                }
            }
        ?>
        <div class="row">
            <div class="col-lg-3 md-3 sm-12">

            </div>
            <div class="col-lg-6 md-6 sm-12">
                <div class="box recturerbox">
                    <h1 class="form_head">UPDATE RECTURER</h1>
                    <form class="mainform" action="updaterecturer.php" method="POST">
                        <input class="input" type="hidden" name="recturerId" value="<?php echo $data['recturerId'];?>" placeholder="Enter First Name Here">
                        <label class="label" for="first name">First Name:</label><br>
                        <input class="input" type="text" name="fname" value="<?php echo $data['firstName'];?>" placeholder="Enter First Name Here">
                        <label class="label" for="last name">Last Name:</label><br>
                        <input class="input" type="text" name="lname" value="<?php echo $data['lastName'];?>" placeholder="Enter last Name Here"><br>
                        <label class="label" for="gender">Gender:</label><br>
                        <input class="radio" type="radio" name="gender" value="Male" Required>Male
                        <input class="radio" type="radio" name="gender" value="Female" Required>Female<br>
                        <label class="label" for="email">Email-Address:</label><br>
                        <input class="input" type="email" name="email" value="<?php echo $data['email'];?>" placeholder="Enter email Here">             
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <input class="button button1 btn btn-primary recturerupdate" type="submit" name="save" value="Update">

                            </div>
                        </div> 
                    </form>
                </div>
                <center><a href="recturerlist.php"><div class="btn btn-primary recturerback">Back</div></a></center>
            </div>
            <div class="col-lg-3 md-3 sm-12">
                
            </div>
        </div>





    </div>
</body>
</html>

