<?php
    include("heading.php");
    $department_session = $_SESSION['regnumber'];
    $selected_data = mysqli_query($conn, "SELECT student.regNumber, student.firstName, student.userType, department.departmentName FROM student, department WHERE student.departmentId = department.departmentId AND student.regNumber = '$department_session'");

    $fail = mysqli_query($conn, "SELECT marks.status, module.numberOfCredits FROM marks, module WHERE marks.status = 'FAIL' AND regNumber = '$department_session' AND marks.yearId = 1 AND marks.moduleCode = module.moduleCode");
    $f = array();
    $c = array();
    while($statusrow2 = mysqli_fetch_array($fail))
    {
    $number_of_fail = $statusrow2['status'];
    $number_of_credits = $statusrow2['numberOfCredits'];
    array_push($f, $number_of_fail);
    array_push($c, $number_of_credits);
    } 
    $count_fail = count($f);
    $sum_of_credits = array_sum($c);
?>

        <div class="row bo body">
            <a href="bityear1.php"><div class="btn btn-primary back">Back</div></a>
            <div class=" links col-lg-4 md-12">
                <ul>
                    <a href="english1.php"><li class="module btn btn-primary">English For Academic Purposes</li></a>
                    <a href="financial.php"><li class="module btn btn-primary">Introduction to Financial Accounting</li></a>
                    <a href="management.php"><li class="module btn btn-primary">Business Management</li></a>
                    <a href="organization.php"><li class="module btn btn-primary">Organization Theory and Behaviors</li></a>
                    <a href="it.php"><li class="module btn btn-primary">Information Technology</li></a>
                    <a href="citizenship.php"><li class="module btn btn-primary">Citizenship and Transformative Education</li></a>
                    <a href="economicsmodule.php"><li class="module btn btn-primary">Principles of Economics</li></a>
                    <a href="architecture.php"><li class="module btn btn-primary">Computer Architecture</li></a>
                    <a href="fundamentalmathematics.php"><li class="module btn btn-primary">Fundamentals of Mathematics</li></a>
                    <a href="intermediate.php"><li class="module btn btn-primary">Intermediate to Financial Accounting</li></a>
                    <a href="entrepreneurship.php"><li class="module btn btn-primary">Entrepreneurship and Innovation</li></a>
                </ul>     
            </div>
            <div class="results col-lg-8 md-12">    
                <p><strong>Regnumber:</strong><?php echo " " . $_SESSION['regnumber']; ?></p>
                <span><strong>Names:</strong><?php echo " " . $_SESSION['fname']; ?></span> <span><?php echo $_SESSION['lname']; ?></span>
                <p><strong>Department:</strong><?php while($selected_data_row = mysqli_fetch_array($selected_data))
                    {
                    echo " " .  $selected_data_row['departmentName'];
                    }  
                    ?>
                    <?php 
                        if($count_fail >= 1 && $sum_of_credits < 25)
                        {
                        $status = "PROGRESS WITH RETAKE";     
                        }
                        elseif($count_fail > 1 && $sum_of_credits >= 25)
                        {
                        $status = "REPEAT THE YEAR";         
                        }
                        else
                        {
                        $status = "PROGRESS";           
                        }
                           

                    ?>

                </p>
                <strong><span>Remark:<?php echo " " . $status . "/";?></span> <span class = "warning"><?php echo $sum_of_credits . "  CREDITS TO RETAKE";?></span></strong>
                <table width="200" class="annualtable table1 table table-striped table-hover">
                    <thead class=" text-light bg-primary">
                        <tr>

                            <th>NO</th>
                            <th>MODULES</th>
                            <th>No CREDITS</th>
                            <th>MARKS %</th>
                            <th>DECISION</th>
                        </tr>
                    </thead>
                    <?php 
                    $x = 1;
                    $select = mysqli_query($conn," SELECT marks.totalPercent, marks.status,  module.name, module.numberOfCredits FROM marks, module WHERE marks.moduleCode = module.moduleCode AND marks.regNumber = '$department_session' AND module.yearId = 1");
                    while($rows = mysqli_fetch_array($select))
                    {
                    ?>
                    <tr>
                        <td><?php echo $x;?></td>
                        <td><?php echo $rows['name'];?></td>
                        <td><?php echo $rows['numberOfCredits'];?></td>
                        <td><?php echo $rows['totalPercent'];?></td>
                        <td><?php echo $rows['status'];?></td>
                        </tr>

                    <?php $x++; } ?>
                </table> 
                <div class="btn btn-primary download" onclick="window.print()">Print</div>
            </div>
            

        </div>
   </div>
</body>
</html>