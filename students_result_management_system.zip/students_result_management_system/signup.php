<?php
    include("connection.php");
        $message = "";
    if(isset($_POST['save']))
    {
        $regnumber = $_POST['regnumber'];
        $password = $_POST['password'];
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $gender = $_POST['gender'];
        $phonenumber = $_POST['phonenumber'];
        $email = $_POST['email'];
        $yearofstudy = $_POST['yearofstudy'];
        $department = $_POST['department'];
        $password2 = md5($password);
        $student_select = mysqli_query($conn, "SELECT * FROM student WHERE regNumber = '$regnumber' LIMIT 1");
        if($student_select && mysqli_num_rows($student_select) > 0)
        {
            header("location:signup.php");

        }
        if(!empty($regnumber) && !empty($password) && !empty($fname) && !empty($lname) && !empty($gender) && !empty($phonenumber) && !empty($email) && !empty($yearofstudy) && !empty($department))
        {
            $query_to_insert = "INSERT INTO student VALUES('$regnumber','$password','$fname','$lname','$gender','$phonenumber','$email','$yearofstudy','$department','Student')";
            $insert = mysqli_query($conn, $query_to_insert);
            if($insert)
            {
                header("location:index.php");
            }
            else{
                header("location:signup.php");
            }
        }
        else{
            $message = "All Fields Are Required";
        }
    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>signup form</title>
    <link rel="stylesheet" href="./bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <style type="text/css">
        
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-12">
               
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12">
                <div class="box">
                    <h1 class="form_head">SIGN UP FORM</h1>
                    <center><span class="message"><?php echo $message;?></span></center>
                    <div class="row">
                        <div class="col-lg-3 md-12 sm-12">
                           

                        </div>
                        <div class="col-lg-6 md-12 sm-12">
                            

                        </div>
                        <div class="col-lg-3 md-12 sm-12">
                           

                        </div>
                    </div>
                    <form action="signup.php" method="POST">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="regnumber">Reg Number:</label><br>
                                <input class="input" type="number" name="regnumber"  minlength="12" placeholder="Enter Your Reg Number"><br>

                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="password">Password:</label><br>
                                <input class="input" type="password" name="password" placeholder="Enter Your Password"><br>

                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="fname">First Name:</label><br>
                                <input class="input" type="text" name="fname" placeholder="Enter Your First Name">
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="lname">Last Name:</label><br>
                                <input class="input" type="text" name="lname" placeholder="Enter Your Last Name">

                            </div>
                        </div>
                        <label class="label" for="gender">Gender:</label><br>
                        <input class="radio" type="radio" name="gender" value="Male" Required>Male
                        <input class="radio" type="radio" name="gender" value="Female" Required>Female
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="phone">Phone Number:</label><br>
                                <input class="input" type="text" name="phonenumber" placeholder="Enter Your Phone Number">
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="email">Email Adress:</label><br>
                                <input class="input" type="email" name="email" placeholder="Enter Your Email Adress">

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="yearofstudy">Year Of Study:</label><br>
                                <select class="input" name="yearofstudy">
                                    <?php
                                        $year = mysqli_query($conn, "SELECT * FROM year_of_study");
                                        while($year_data = mysqli_fetch_array($year))
                                        {
                                    ?>
                                    <option value="<?php echo $year_data['yearOfStudy'];?>"><?php echo $year_data['yearOfStudy'];?></option>
                                    <?php }?> 
                                </select>

                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="department">Department:</label><br>
                                <select class="input" name="department">
                                    <?php
                                        $department = mysqli_query($conn, "SELECT * FROM department");
                                        while($department_data = mysqli_fetch_array($department))
                                        {
                                    ?>
                                    <option value="<?php echo $department_data['departmentId'];?>"><?php echo $department_data['departmentName'];?></option>
                                    <?php }?> 
                                </select>

                            </div>
                        </div>                      
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <input class="button button1 btn btn-primary" type="submit" name="save" value="Sign Up">

                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <input class="button button2 btn btn-danger" type="reset" value="Cancel">
                                
                            </div>
                            <center><p>Already have an account <a href="index.php">Login</a> </p></center>
                            
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12">
            
            </div>
        </div>
    </div>
    
</body>
</html>