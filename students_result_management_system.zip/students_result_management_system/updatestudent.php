        <?php
            include("adminheading.php");
            $regNumber=$_GET['regNumber'];
            $select = mysqli_query($conn,"SELECT * FROM student WHERE regNumber = '$regNumber' LIMIT 1");
            $data=mysqli_fetch_assoc($select);
            if(isset($_POST['save']))
            {
                $regnumber = $_POST['regnumber'];
                $password = $_POST['password'];
                $fname = $_POST['fname'];
                $lname = $_POST['lname'];
                $gender = $_POST['gender'];
                $phonenumber = $_POST['phonenumber'];
                $email = $_POST['email'];
                $yearofstudy = $_POST['yearofstudy'];
                $department = $_POST['department'];
                $usertype = $_POST['usertype'];
                $update=mysqli_query($conn,"UPDATE student SET regNumber='$regnumber', password='$password', firstName='$fname', lastName='$lname', gender='$gender', phoneNumber='$phonenumber', email='$email', yearOfStudy='$yearofstudy', departmentId='$department', userType='$usertype' WHERE regNumber = '$regnumber'");
                if($update)
                {
                    header("location:students.php");
                }
                else{
                    header("location:updatestudent.php");
                }
            }
        


        ?>

        <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-12">
               
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12">
                <div class="box">
                    <h1 class="form_head">UPDATE STUDENT FORM</h1>
                    <div class="row">
                        <div class="col-lg-3 md-12 sm-12">
                           

                        </div>
                        <div class="col-lg-6 md-12 sm-12">
                            

                        </div>
                        <div class="col-lg-3 md-12 sm-12">
                           

                        </div>
                    </div>
                    <form action="updatestudent.php" method="POST">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="regnumber">Reg Number:</label><br>
                                <input class="input" type="number" name="regnumber" value="<?php echo $data['regNumber'];?>" required readonly><br>

                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="password">Password:</label><br>
                                <input class="input" type="text" name="password" value="<?php echo $data['password'];?>" required><br>

                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="fname">First Name:</label><br>
                                <input class="input" type="text" name="fname" value="<?php echo $data['firstName'];?>" required>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="lname">Last Name:</label><br>
                                <input class="input" type="text" name="lname" value="<?php echo $data['lastName'];?>" required>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 md-6 sm-12">
                                <label class="label" for="gender">Gender:</label><br>
                                <input class="radio" type="radio" name="gender" value="Male" Required>Male
                                <input class="radio" type="radio" name="gender" value="Female" Required>Female

                            </div>
                            <div class="col-lg-6 md-6 sm-12">
                                <label class="label" for="phone">Phone Number:</label><br>
                                <input class="input" type="text" name="phonenumber" value="<?php echo $data['phoneNumber'];?>" required>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="email">Email Adress:</label><br>
                                <input class="input" type="email" name="email" value="<?php echo $data['email'];?>" required>
                               
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="yearofstudy">Year Of Study:</label><br>
                                <select class="input" name="yearofstudy">
                                    <?php
                                        $year = mysqli_query($conn, "SELECT * FROM year_of_study");
                                        while($year_data = mysqli_fetch_array($year))
                                        {
                                    ?>
                                    <option value="<?php echo $year_data['yearOfStudy'];?>"><?php echo $year_data['yearOfStudy'];?></option>
                                    <?php }?> 
                                </select>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="department">Department:</label><br>
                                <select class="input" name="department">
                                    <?php
                                        $department = mysqli_query($conn, "SELECT * FROM department");
                                        while($department_data = mysqli_fetch_array($department))
                                        {
                                    ?>
                                    <option value="<?php echo $department_data['departmentId'];?>"><?php echo $department_data['departmentName'];?></option>
                                    <?php }?> 
                                </select>

                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="department">User Type:</label><br>
                                <select class="input" name="usertype">
                                    <?php
                                        $role = mysqli_query($conn, "SELECT * FROM role");
                                        while($role_data = mysqli_fetch_array($role))
                                        {
                                    ?>
                                    <option value="<?php echo $role_data['role'];?>"><?php echo $role_data['role'];?></option>
                                    <?php }?> 
                                </select>
                                
                            </div>
                        </div>                      
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                

                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <input class="button button1 btn btn-primary" type="submit" name="save" value="Update">
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                
                                
                            </div>
                            
                            
                        </div>
                    </form>
                </div>

                <center><a href="students.php"><div class="btn btn-primary recturerback">Back</div></a></center>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12">
            
            </div>
        </div>



    </div>
</body>
</html>