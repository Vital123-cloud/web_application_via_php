<?php
$conn = mysqli_connect("localhost","root","","university_of_rwanda_db");
if($conn)
{
}
else{
    die("failed to connect");
}


?>