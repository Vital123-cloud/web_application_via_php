<?php
include("adminheading.php");
?>

        <div class="row">
            <div class="col-lg-3 md-12">
               <ul>
                    <a href="admin.php"><div class="module btn btn-primary">Back</div></a>
               </ul>
               
                
            </div>
            
            <div class="col-lg-3 md-12">
            <a class="module btn btn-primary printmarks" onclick="window.print()" href="">Print</a>
               
                
            </div>
            <div class="col-lg-3 md-12">
               
               
                
            </div>
        </div>
        <div class="row body">
            <div class="col-lg-12 md-12">
                <h1 class="heading1 bg-primary">ALL REGISTERED STUDENTS</h1>
                <div class="column">
                    <table class="allmarks table1 table table-striped table-hover">
                        <thead class=" text-light bg-primary">
                            <tr>
                                <th>REGNUMBER</th>
                                <th>FIRSTNAME</th>
                                <th>LASTNAME</th>
                                <th>GENDER</th>
                                <th>PHONE</th>
                                <th>EMAIL</th>
                                <th>YEAR</th>
                                <th>DEPARTMENT</th>
                                <th>USER</th>
                                <th colspan="2">ACTION</th>
                            </tr>
                        </thead>
                        <?php 
                            $x=1;
                            $select = mysqli_query($conn,"SELECT student.regNumber, student.firstName, student.lastName, student.gender, student.phoneNumber, student.email, student.yearOfStudy, department.departmentName, student.userType FROM student, department WHERE student.departmentId = department.departmentId");
                                while($rows = mysqli_fetch_array($select))
                                {

                        ?>
                        <tr>
                            <td><?php echo $rows['regNumber'];?></td>
                            <td><?php echo $rows['firstName'];?></td>
                            <td><?php echo $rows['lastName'];?></td>
                            <td><?php echo $rows['gender'];?></td>
                            <td><?php echo $rows['phoneNumber'];?></td>
                            <td><?php echo $rows['email'];?></td>
                            <td><?php echo $rows['yearOfStudy'];?></td>
                            <td><?php echo $rows['departmentName'];?></td>
                            <td><?php echo $rows['userType'];?></td>
                            <td><a href="updatestudent.php?regNumber=<?=$rows['regNumber'];?>"><span class="btn btn-primary">Update</span></a></td>
                            <td><a href="deletestudent.php?regNumber=<?=$rows['regNumber'];?>"><span onclick="return confirmDelete();" class="btn btn-danger">Delete</span></a></td>
                            
                        </tr>
                        <?php $x++; } ?>
                    </table>
                </div>
                
            </div>

        </div>
   </div>
</body>
</html>