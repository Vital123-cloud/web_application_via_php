<?php
    include("heading.php");
    $department_session = $_SESSION['regnumber'];
    $selected_data = mysqli_query($conn, "SELECT student.regNumber, student.firstName, department.departmentName FROM student, department WHERE student.departmentId = department.departmentId AND student.regNumber = '$department_session'");  
?>
        <div class="row bo body">
            <a href="bityear1.php"><div class="btn btn-primary back">Back</div></a>
            <div class=" links col-lg-4 md-12">
                <ul>
                    <a href="english1.php"><li class="module btn btn-primary">English For Academic Purposes</li></a>
                    <a href="financial.php"><li class="module btn btn-primary">Introduction to Financial Accounting</li></a>
                    <a href="management.php"><li class="module btn btn-primary">Business Management</li></a>
                    <a href="organization.php"><li class="module btn btn-primary">Organization Theory and Behaviors</li></a>
                    <a href="it.php"><li class="module btn btn-primary">Information Technology</li></a>
                    <a href="citizenship.php"><li class="module btn btn-primary">Citizenship and Transformative Education</li></a>
                    <a href="economicsmodule.php"><li class="module btn btn-primary">Principles of Economics</li></a>
                    <a href="architecture.php"><li class="module btn btn-primary">Computer Architecture</li></a>
                    <a href="fundamentalmathematics.php"><li class="module btn btn-primary">Fundamentals of Mathematics</li></a>
                    <a href="intermediate.php"><li class="year_active module btn btn-primary">Intermediate to Financial Accounting</li></a>
                    <a href="entrepreneurship.php"><li class="module btn btn-primary">Entrepreneurship and Innovation</li></a>
                </ul>     
            </div>
            <div class="results col-lg-8 md-12">
                <p><strong>Regnumber:</strong><?php echo " " . $_SESSION['regnumber']; ?></p>
                <span><strong>Names:</strong><?php echo " " . $_SESSION['fname']; ?></span> <span><?php echo $_SESSION['lname']; ?></span>
                <p><strong>Department:</strong><?php while($selected_data_row = mysqli_fetch_array($selected_data))
                    {
                    echo " " .  $selected_data_row['departmentName'];
                    }  ?>
                </p>
                    <?php 
                        $select = mysqli_query($conn,"SELECT module.name, module.numberOfCredits, marks.quizAndAssignments, marks.cat, marks.totalCatAndAssignments, marks.finalExam, marks.totalPercent, marks.status, year_of_study.yearOfStudy FROM module, marks, year_of_study WHERE marks.moduleCode = module.moduleCode AND marks.regNumber = '$department_session' AND module.name = 'Intermediate to Financial Accounting' AND marks.yearId = year_of_study.yearId");
                        while($rows = mysqli_fetch_array($select))
                        {
                    ?>
                <p><strong>YEAR OF STUDY:</strong><?php echo " " . $rows['yearOfStudy'];?></p>
                <p><strong>MODULE:</strong><?php echo " " . $rows['name'];?></p>

                    <table width="200" class="table1 table table-striped table-hover">
                        <thead class=" text-light bg-primary">
                            <tr>
                                <th>MARKS TYPE</th>
                                <th>MARKS</th>
                            </tr>
                        </thead>
                        <?php 
                            

                        ?>
                        <tr>
                            <td><strong>QUIZ & ASSIGNMENT/20</strong></td>
                            <td><?php echo $rows['quizAndAssignments'];?></td>
                        </tr>
                        <tr>
                            <td><strong>CAT/30</strong></td>
                            <td><?php echo $rows['cat'];?></td>
                        </tr>
                        <tr>
                            <td><strong>CAT + QUIZ & ASSIGNMENT/50</strong></td>
                            <td><?php echo $rows['totalCatAndAssignments'];?></td>
                        </tr>
                        <tr>
                            <td><strong>FINAL EXAM/50</strong></td>
                            <td><?php echo $rows['finalExam'];?></td>
                        </tr>
                        <tr>
                            <td><strong>TOTAL/100</strong></td>
                            <td><?php echo $rows['totalPercent'];?>%</td>
                        </tr>
                        <tr>
                            <td><strong>DECISSION</strong></td>
                            <td><?php echo $rows['status'];?></td>
                        </tr>
                        

                        <?php  } ?>
                    </table>
                    <div class="btn btn-primary download" onclick="window.print()">Print</div> 
                
            </div>
            

        </div>
   </div>
</body>
</html>