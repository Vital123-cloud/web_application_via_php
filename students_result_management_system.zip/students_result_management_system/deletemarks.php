<?php 
    include("connection.php");
    $markId=$_GET['markId'];
    
    $delete = mysqli_query($conn,"DELETE FROM marks WHERE markId=$markId");
	if($delete){
		header("location:studentmarks.php");
	}

?>