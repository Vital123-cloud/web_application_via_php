  <?php
    include("adminheading.php");
    $message = "";
    if(isset($_POST['save']))
    {
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $gender = $_POST['gender'];
        $email = $_POST['email'];
        if(!empty($fname) && !empty($lname) && !empty($gender) && !empty($email))
        {
            if($insert = mysqli_query($conn, "INSERT INTO recturer VALUES('', '$fname','$lname' ,'$gender' , '$email')"))
            {
                header("location:recturerform.php");
            }
        }
        else{
            $message = "All Fields Are Required";
        }
    }
  
  ?>          
            <div class="row">
                <div class="col-lg-3 md-3 sm-12">

                </div>
                <div class="col-lg-6 md-6 sm-12">
                    <div class="box recturerbox">
                        <h1 class="form_head">ADD RECTURERS</h1>
                        <center><span class="message"><?php echo $message;?></span></center>
                        <form class="mainform" action="recturerform.php" method="POST">
                            <label class="label" for="first name">First Name:</label><br>
                            <input class="input" type="text" name="fname" placeholder="Enter First Name Here">
                            <label class="label" for="last name">Last Name:</label><br>
                            <input class="input" type="text" name="lname" placeholder="Enter last Name Here"><br>
                            <label class="label" for="gender">Gender:</label><br>
                            <input class="radio" type="radio" name="gender" value="Male" Required>Male
                            <input class="radio" type="radio" name="gender" value="Female" Required>Female<br>
                            <label class="label" for="email">Email-Address:</label><br>
                            <input class="input" type="email" name="email" placeholder="Enter email Here">             
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-12">
                                    <input class="button button1 btn btn-primary" type="submit" name="save" value="Add">

                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-12">
                                    
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-12">
                                    <input class="button button2 btn btn-danger" type="reset" value="Cancel">
                                    
                                </div>

                            </div> 
                        </form>
                    </div>
                    <center><a href="admin.php"><div class="btn btn-primary recturerback">Back</div></a></center>
                </div>
                <div class="col-lg-3 md-3 sm-12">
                    
                </div>
            </div>
        </div>
    </body>
</html>