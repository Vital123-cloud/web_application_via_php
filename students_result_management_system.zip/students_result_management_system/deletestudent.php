<?php 
    include("connection.php");
    $regNumber=$_GET['regNumber'];
    
    $delete = mysqli_query($conn,"DELETE FROM student WHERE regNumber=$regNumber");
	if($delete){
		header("location:students.php");
	}

?>