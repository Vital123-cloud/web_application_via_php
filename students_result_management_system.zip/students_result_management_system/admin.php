<?php
include("adminheading.php");
   
    if(isset($_POST['save']))
    {
        $quizandassignment = $_POST['quizandassignment'];
        $cat = $_POST['cat'];
        $finalexam = $_POST['finalexam'];
        $module = $_POST['module'];
        $regnumber = $_POST['regnumber'];
        $yearOfStudy = $_POST['yearofstudy2'];
        $total_cat_assignment = $quizandassignment +  $cat;
        $totalmarks = $total_cat_assignment + $finalexam;
        if($totalmarks >= 50)
        {
            $status = "PASS";
        }
        else
        {
            $status = "FAIL";
        }
        

        $query_to_insert = "INSERT INTO marks VALUES('','$quizandassignment','$cat','$total_cat_assignment','$finalexam','$totalmarks','$module','$yearOfStudy','$regnumber','$status')";
        $insert = mysqli_query($conn, $query_to_insert);
        if($insert)
        {
            header("location:admin.php");
        }
        else{
            header("location:index.php");
        }
    }
    if(isset($_POST['save2']))
    {
        $selectedYear = $_POST['yearofstudy'];
        
    }
?>

        <div class="row body">
            <div class="links  col-lg-3 md-12">
               <ul>
               <a href="recturerform.php"><li class="module btn btn-primary">Add Recturers</li></a>
               <a href="moduleform.php"><li class="module btn btn-primary">Add Modules</li></a>
                <a href="studentmarks.php"><li class="module btn btn-primary">Student marks</li></a>
                <a href="students.php"><li class="module btn btn-primary">All registered students</li></a>
                <a href="modulelist.php"><li class="module btn btn-primary">All Modules</li></a>
                <a href="recturerlist.php"><li class="module btn btn-primary">All Recturers</li></a>
               
                
               </ul>
               
                
            </div>
            <div class="col-lg-9 md-12">
               
                <div class="box">
                    <h1 class="form_head">ADD MARKS</h1>
                    <form class="yearsearchboth yearsearch" action="admin.php" method = "POST">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-12">
                                <label class="label" for="yearofstudy">Search Year Of Study:</label><br>
                                <select class="input" name="yearofstudy">
                                    <?php
                                        $year = mysqli_query($conn, "SELECT * FROM year_of_study");
                                        while($year_data = mysqli_fetch_array($year))
                                        {
                    
                                    ?>
                                    <option value="<?php echo $year_data['yearId'];?>">
                                        <?php echo $year_data['yearOfStudy'];?>
                                        </option>
                                    <?php }?> 
                                </select>
                                
                            </div>
                            <div class="yearsearchboth yearsearch col-lg-2 col-md-2 col-sm-12">
                                <input class="searchbutton button button1 btn btn-primary" type="submit" name = "save2" value = "Search">
                            </div>

                        </div>
                        
                    </form>
                    <form class="mainform" action="admin.php" method="POST">
                        <div class="row">
                            <div class="col-lg-6 col-md-12 col-sm-12">
                                <label class="label" for="module">Module:</label><br>
                                <select class="input" name="module" required>
                                    <?php
                                        $module = mysqli_query($conn, "SELECT * FROM module WHERE yearId = '$selectedYear'");
                                        while($module_data = mysqli_fetch_array($module))   
                                        {
                                            
                                    ?>
                                    <option value="<?php echo $module_data['moduleCode'];?>"><?php echo $module_data['name'];?></option>
                                    <?php }?> 
                                </select>
                                <?php

                                ?>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                            <label class="label" for="module">Year Of Study:</label><br>
                            <select class="input" name="yearofstudy2" id="" required>
                                <?php
                                    $select_year = mysqli_query($conn,"SELECT * FROM year_of_study");
                                    while($select_year_row = mysqli_fetch_array($select_year))
                                    {

                                        
                                ?>
                                <option value="<?php echo $select_year_row['yearId'];?>"><?php echo $select_year_row['yearOfStudy'];?></option>
                                <?php }?>
                                
                            </select>
                            </div>
                            
                        </div>
                        
                        <div class="row">
                            
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="reg number">Reg Number:</label><br>
                                <input class="input" type="number" name="regnumber" placeholder="Enter Your Reg Number Here" required>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="cat">Cat/30:</label><br>
                                <input class="input" type="number" name="cat" placeholder="Enter Your Cat Mrks Here" min="0" max="1000" step="0.01" required><br>
                                
                                
                            </div>
                        </div>
                        <div class="row">
                            
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="quiz">Quiz + Assignment/20:</label><br>
                                <input class="input" type="number" name="quizandassignment" placeholder="Enter Your Quiz and Assignment marks Here" min="0" max="1000" step="0.01" required><br>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <label class="label" for="final exam">Final EXam/50:</label><br>
                                <input class="input" type="number" name="finalexam" placeholder="Enter Your Final Exam Marks Here" min="0" max="1000" step="0.01" required>
                            </div>
                           
                            
                        </div>
                                            
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <input class="button button1 btn btn-primary" type="submit" name="save" value="Add">

                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <input class="button button2 btn btn-danger" type="reset" value="Cancel">
                                
                            </div>
                           
                            
                        </div>
                    </form>
                </div>
            </div>

        </div>
   </div>
</body>
</html>