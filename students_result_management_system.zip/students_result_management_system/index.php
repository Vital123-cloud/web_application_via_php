
<?php
    session_start();
    include("connection.php");
    $message = "";
    if(isset($_POST['save']))
    {
        $regnumber = $_POST['regnumber'];
        $password = $_POST['password'];
        
        if(!empty($regnumber) && !empty($password))
        {
            //read from database
            if($query = "SELECT * FROM student WHERE regNumber ='$regnumber' LIMIT 1")
            {
                $result = mysqli_query($conn,$query);
                if($result && mysqli_num_rows($result) >0) 
                {
                    $user_data = mysqli_fetch_assoc($result);
                    $real_regnumber = $user_data['regNumber'];
                    $real_password = $user_data['password'];
                    $_SESSION['fname'] = $user_data['firstName'];
                    $_SESSION['regnumber'] = $user_data['regNumber'];
                    $_SESSION['lname'] = $user_data['lastName'];
                    $_SESSION['user_type'] = $user_data[9];
                    if ($real_regnumber == $regnumber && $real_password == $password) 
                    {
                        if($user_data['userType'] == "Student")
                        {
                            header("location:dashboard.php"); 
                        }
                        elseif($user_data['userType'] == "Admin")
                        {
                            header("location:admin.php");
                        }
                        else{
                            header("location:index.php");

                        }
                    }
                    else
                    {
                        header("location:index.php");
                        

                    }
                }
                else{
                    $message = "Regnumber Not Exist";

                }
            }
        }
        else
        {
            $message = "All Fealds Are Required";
        }
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN FORM</title>
    <link rel="stylesheet" href="./bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-12">
               
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12">
                <div class="box box_login">
                    <h1 class="form_head">LOG IN FORM</h1>
                    <center><span class="message"><?php echo $message;?></span></center>
                    <form action="index.php" method="POST">     
                        <label class="label" for="regnumber">Reg Number:</label><br>
                        <input class="input" type="number" name="regnumber" placeholder="Enter Your Reg Number"><br>                     
                        <label class="label" for="password">Password:</label><br>
                        <input class="input" type="password" name="password" placeholder="Enter Your Password"><br>                  
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <input class="button button1 btn btn-primary" type="submit" name="save" value="Log In">

                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <input class="button button2 btn btn-danger" type="reset" value="Cancel">
                                
                            </div>
                            <center><p>Don't have an Account <a href="signup.php">Create Account</a> </p></center>
                            
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12">
            
            </div>
        </div>
    </div>
    
</body>
</html>