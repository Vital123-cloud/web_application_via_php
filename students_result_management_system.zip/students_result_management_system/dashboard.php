<?php
    include("heading.php");
?>

        <div class="row bo body">
        
               
            <div class="box boxyear modules col-lg-4 md-12">
                <h2 class="selectyear header2 bg-primary text-light">SELECT YEAR OF STUDY</h2>
                <a class=" module btn btn-primary" href="bityear1.php">Year One</a> <br>
                <a class=" module btn btn-primary" href="bityear2.php">Year Two</a> <br>
                <a class=" module btn btn-primary" href="bityear3.php">Year Three</a> <br>
                <a class=" module btn btn-primary" href="bityear4.php">Year Four</a> <br>
            </div>
            <div class="col-lg-1 md-12">
               
                
            </div>
            
                
            
            
            <div class="col-lg-1 md-12">
               
                
            </div>
            
            

        </div>
   </div>
</body>
</html>